package main.java.gui;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JTextField;

import main.java.Manager.DBFormat;

public class DBParseXpath extends AbstractAction {

	/**
	 * 
	 */
	private JTextField requete ;
	private static final long serialVersionUID = 1L;
	public DBParseXpath(String texte, JTextField req) {
		super(texte);
		requete = req;
	}
	 DBFormat xpathRequester (String request){
		DBFormat result = null;
		
		return result;
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		requete.getText();
		
	}
}
